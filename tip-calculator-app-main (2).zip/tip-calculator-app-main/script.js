const billInput = document.querySelector("input#first");
const peopleInput = document.querySelector("input#fifth");
const tipPar = document.querySelector("p#sixth");
const totalPar = document.querySelector("p#seventh");
const customInput = document.querySelector("input#third");
const resetBtn = document.querySelector(".resetBtn");

const btns = document.getElementsByClassName("btn");

function displayTips(percentage) {
    const amountPerPerson = billInput.value / peopleInput.value;
    let tipPerPerson = amountPerPerson * (percentage/100);
    tipPerPerson = tipPerPerson.toFixed(2);
    const totalPerPerson = amountPerPerson + parseFloat(tipPerPerson);

    tipPar.innerHTML = "$" + tipPerPerson;
    totalPar.innerHTML = "$" + totalPerPerson.toFixed(2);
}


for(let i = 0; i < btns.length; i++){
    btns[i].addEventListener("click", function(){
    const percentage = parseInt(btns[i].innerHTML);
    displayTips(percentage);
    
})
}

customInput.onchange = function() {
    const percentage = parseInt(customInput.value);
    displayTips(percentage);
    
}
resetBtn.onclick = function(){
    billInput.value = "";
    peopleInput.value = "";
    tipPar.innerHTML = "$0.00";
    totalPar.innerHTML = "$0.00";
}